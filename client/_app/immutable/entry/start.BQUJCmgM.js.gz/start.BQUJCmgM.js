import{a as t}from"../chunks/DbYbgSu2.js";export{t as start};
